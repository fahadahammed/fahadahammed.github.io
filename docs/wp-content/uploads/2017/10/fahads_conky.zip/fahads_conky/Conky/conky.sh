#!/bin/bash



#-----Created By-----#
#-----Fahad Ahammed-----#
#-----http://www.obakfahad.com-----#



# Kill Conky If Running . If you want to run this conky along with other
# Put a "#" Symbol before the "test" word from below line .
test -z "`pgrep conky`" || killall -9 conky

# The directory of conkyrcs
#conky_dir="./conkyrc"

# The command for start conkys
START="conky -d -c"

# The Conkys
sleep 0.5
$START /home/fahad/Conky/conkyrc/cpu
sleep 0.2
$START /home/fahad/Conky/conkyrc/time
sleep 0.2
$START /home/fahad/Conky/conkyrc/mem
sleep 0.2
$START /home/fahad/Conky/conkyrc/disk
sleep 0.2
$START /home/fahad/Conky/conkyrc/net
sleep 0.2
$START /home/fahad/Conky/conkyrc/foxconky
